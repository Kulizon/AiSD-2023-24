### Aby skompilowac i uruchomic program nalezy uzyc komendy:
```console
make
```

### Aby uruchomic skompilowany program nalezy uzyc komendy:
```console
make run
```